import importlib.util,itertools,json,pathlib,sys
from spectra.cnf import CNF,solve_deductive
import spectra.cnf.deductive
assert pathlib.Path(spectra.cnf.deductive.__file__).is_relative_to(pathlib.Path(sys.prefix))
assert all(importlib.util.find_spec(p) is None for p in ('torch','numpy','pytest','pysat'))
clauses=[(),(1,),(-1,),(2,),(-2,),(1,2),(1,-2),(-1,2),(-1,-2)]
for mask in range(1<<len(clauses)):
 p=CNF(2,tuple(c for i,c in enumerate(clauses) if mask&(1<<i)))
 r=solve_deductive(p,max_flips=0)
 expected=any(p.satisfied(w) for w in itertools.product((False,True),repeat=2))
 assert (r.status=='SAT_VERIFIED')==expected
print(json.dumps({'status':'PASS','exhaustive_binary_formulas':512,'optional_dependencies':False,'scope':'installed wheel outside checkout'}))
