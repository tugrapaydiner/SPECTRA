# M14 Attempt 5 result table

Evidence surface: **confirmation**

Candidate: original dim-64 dual-stream FP TRM with reference-free semantic early exit.

| config | semantic validity | median complete-solve ms | mean supervision steps | mean shared-block apps | early-exit fraction | role |
|---|---:|---:|---:|---:|---:|---|
| symbolic_exact | 1.000000 | 0.268091 |  |  |  | context |
| dual_stream_exit_k4 | 0.984570 | 0.648583 | 1.2482 | 2.4965 | 0.9846 | candidate |
| single_pass_fp | 0.842383 | 0.661825 |  | 2.0000 |  | primary baseline |
| single_pass_int8 | 0.841992 | 0.785637 |  | 2.0000 |  | context |

Complete-solve latency includes every executed dual-stream recurrence step and semantic validity check. Unmatched points are not called iso-budget.
